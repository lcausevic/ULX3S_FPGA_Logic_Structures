library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity brojac8 is
    Port (
        clk_25m  : in  STD_LOGIC;
        btn_down : in  STD_LOGIC;
        led      : out STD_LOGIC_VECTOR(7 downto 0)
    );
end brojac8;

architecture Behavioral of brojac8 is

    signal brojac : UNSIGNED(7 downto 0) := (others => '0');

    signal prescaler : INTEGER range 0 to 24999999 := 0;

begin

    process(clk_25m, btn_down)
    begin

        -- Asinhroni reset
        if btn_down = '1' then

            brojac    <= (others => '0');
            prescaler <= 0;

        elsif rising_edge(clk_25m) then

            -- 25 000 000 taktova = 1 sekunda
            if prescaler = 24999999 then

                prescaler <= 0;
                brojac <= brojac + 1;

            else

                prescaler <= prescaler + 1;

            end if;

        end if;

    end process;

    led <= STD_LOGIC_VECTOR(brojac);

end Behavioral;