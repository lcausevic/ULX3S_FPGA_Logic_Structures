run_tcl -fg brojac8_impl1_synplify.tcl
