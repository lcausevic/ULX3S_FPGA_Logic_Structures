run_tcl -fg mux4x1_impl1_synplify.tcl
