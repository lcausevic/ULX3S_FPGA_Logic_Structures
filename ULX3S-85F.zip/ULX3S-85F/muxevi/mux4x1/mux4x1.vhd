library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity mux4x1_tip2 is
    Port (
        sw  : in  STD_LOGIC_VECTOR(3 downto 0);
        led : out STD_LOGIC_VECTOR(7 downto 0)
    );
end mux4x1_tip2;

architecture Behavioral of mux4x1_tip2 is

    signal A, B, C, D : STD_LOGIC;
    signal y : STD_LOGIC;

begin

    A <= sw(3);
    B <= sw(2);
    C <= sw(1);
    D <= sw(0);

    process(sw)
    begin

        case sw(3 downto 2) is

            -- A B = 00
            when "00" =>
                y <= ((NOT sw(1)) AND (NOT sw(0)))
                     OR
                     (sw(1) AND sw(0));

            -- A B = 01
            when "01" =>
                y <= sw(1) AND sw(0);

            -- A B = 10
            when "10" =>
                y <= NOT sw(0);

            -- A B = 11
            when "11" =>
                y <= sw(1);

            when others =>
                y <= '0';

        end case;

    end process;

    led(0) <= y;
    led(7 downto 1) <= "0000000";

end Behavioral;