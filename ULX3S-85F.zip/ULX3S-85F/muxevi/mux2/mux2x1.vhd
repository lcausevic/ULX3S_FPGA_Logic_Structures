library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity mux2x1 is
    Port (
        sw  : in  STD_LOGIC_VECTOR(3 downto 0);
        led : out STD_LOGIC_VECTOR(7 downto 0)
    );
end mux2x1;

architecture Behavioral of mux2x1 is

    signal d0 : STD_LOGIC;
    signal d1 : STD_LOGIC;
    signal s  : STD_LOGIC;
    signal y  : STD_LOGIC;

begin

    d0 <= sw(0);
    d1 <= sw(1);
    s  <= sw(2);

    y <= d0 when s = '0' else d1;

    led(0) <= y;
    led(7 downto 1) <= "0000000";

end Behavioral;