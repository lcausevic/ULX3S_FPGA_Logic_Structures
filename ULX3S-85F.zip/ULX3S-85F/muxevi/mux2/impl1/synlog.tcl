run_tcl -fg mux2x1_impl1_synplify.tcl
