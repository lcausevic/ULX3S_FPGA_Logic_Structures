run_tcl -fg mux16x1_impl1_synplify.tcl
