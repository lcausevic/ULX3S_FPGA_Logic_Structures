library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity mux16x1 is
    Port (
        sw  : in  STD_LOGIC_VECTOR(3 downto 0);
        led : out STD_LOGIC_VECTOR(7 downto 0)
    );
end mux16x1;

architecture Behavioral of mux16x1 is

    signal y : STD_LOGIC;

begin

    process(sw)
    begin

        case sw is

            when "0000" =>
                y <= '1';

            when "0011" =>
                y <= '1';

            when "0111" =>
                y <= '1';

            when "1000" =>
                y <= '1';

            when "1010" =>
                y <= '1';

            when "1110" =>
                y <= '1';

            when "1111" =>
                y <= '1';

            when others =>
                y <= '0';

        end case;

    end process;

    led(0) <= y;
    led(7 downto 1) <= "0000000";

end Behavioral;