library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity test_mux16x1 is
end test_mux16x1;

architecture Behavioral of test_mux16x1 is

    signal sw_tb  : STD_LOGIC_VECTOR(3 downto 0);
    signal led_tb : STD_LOGIC_VECTOR(7 downto 0);

begin

    DUT : entity work.mux16x1
        port map (
            sw  => sw_tb,
            led => led_tb
        );

    stimulus : process
    begin

        sw_tb <= "0000";
        wait for 10 ns;

        sw_tb <= "0001";
        wait for 10 ns;

        sw_tb <= "0010";
        wait for 10 ns;

        sw_tb <= "0011";
        wait for 10 ns;

        sw_tb <= "0100";
        wait for 10 ns;

        sw_tb <= "0101";
        wait for 10 ns;

        sw_tb <= "0110";
        wait for 10 ns;

        sw_tb <= "0111";
        wait for 10 ns;

        sw_tb <= "1000";
        wait for 10 ns;

        sw_tb <= "1001";
        wait for 10 ns;

        sw_tb <= "1010";
        wait for 10 ns;

        sw_tb <= "1011";
        wait for 10 ns;

        sw_tb <= "1100";
        wait for 10 ns;

        sw_tb <= "1101";
        wait for 10 ns;

        sw_tb <= "1110";
        wait for 10 ns;

        sw_tb <= "1111";
        wait for 10 ns;

        wait;

    end process;

end Behavioral;