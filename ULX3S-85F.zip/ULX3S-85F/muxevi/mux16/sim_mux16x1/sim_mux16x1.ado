setenv SIM_WORKING_FOLDER .
set newDesign 0
if {![file exists "C:/Users/Korisnik/Desktop/primjeri dipl/muxevi/mux16/sim_mux16x1/sim_mux16x1.adf"]} { 
	design create sim_mux16x1 "C:/Users/Korisnik/Desktop/primjeri dipl/muxevi/mux16"
  set newDesign 1
}
design open "C:/Users/Korisnik/Desktop/primjeri dipl/muxevi/mux16/sim_mux16x1"
cd "C:/Users/Korisnik/Desktop/primjeri dipl/muxevi/mux16"
designverincludedir -clear
designverlibrarysim -PL -clear
designverlibrarysim -L -clear
designverlibrarysim -PL pmi_work
designverlibrarysim ovi_ecp5u
designverdefinemacro -clear
if {$newDesign == 0} { 
  removefile -Y -D *
}
addfile "C:/Users/Korisnik/Desktop/primjeri dipl/muxevi/mux16/mux16x1.vhd"
addfile "C:/Users/Korisnik/Desktop/primjeri dipl/muxevi/mux16/test_mux16x1.vhd"
vlib "C:/Users/Korisnik/Desktop/primjeri dipl/muxevi/mux16/sim_mux16x1/work"
set worklib work
adel -all
vcom -dbg -work work "C:/Users/Korisnik/Desktop/primjeri dipl/muxevi/mux16/mux16x1.vhd"
vcom -dbg -work work "C:/Users/Korisnik/Desktop/primjeri dipl/muxevi/mux16/test_mux16x1.vhd"
entity test_mux16x1
vsim  +access +r test_mux16x1   -PL pmi_work -L ovi_ecp5u
add wave *
run 1000ns
