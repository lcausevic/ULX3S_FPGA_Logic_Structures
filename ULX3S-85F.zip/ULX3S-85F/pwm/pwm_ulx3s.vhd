library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity pwm_ulx3s is
    Port (
        clk_25m  : in  STD_LOGIC;
        btn_down : in  STD_LOGIC;
        sw       : in  STD_LOGIC_VECTOR(3 downto 0);
        led      : out STD_LOGIC_VECTOR(7 downto 0)
    );
end pwm_ulx3s;


architecture Structural of pwm_ulx3s is

    signal duty_cycle : UNSIGNED(7 downto 0);
    signal pwm_signal : STD_LOGIC;

begin

    -- Skaliranje 4-bitne vrijednosti 0..15
    -- na 8-bitnu vrijednost 0..255
    duty_cycle <= unsigned(sw & sw);


    PWM_GENERATOR : entity work.pwm_core
        generic map (
            PWM_BITS    => 8,
            CLK_CNT_LEN => 5
        )
        port map (
            clk        => clk_25m,
            reset      => btn_down,
            duty_cycle => duty_cycle,
            pwm_out    => pwm_signal
        );


    led(0) <= pwm_signal;
    led(7 downto 1) <= "0000000";

end Structural;