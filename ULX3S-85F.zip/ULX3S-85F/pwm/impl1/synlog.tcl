run_tcl -fg pwm_impl1_synplify.tcl
