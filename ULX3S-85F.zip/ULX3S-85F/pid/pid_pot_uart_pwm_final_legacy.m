%% FINAL: ULX3S + POT + PID + PWM + MATLAB MODEL DC MOTORA
% Legacy MATLAB verzija: serial / fopen / fwrite / fread
%
% Potenciometar -> MAX11125 AIN0 -> referenca r(k)
% MATLAB model -> y(k) -> UART -> FPGA
% FPGA -> PID -> u(k)
% u(k) -> PWM na ULX3S
% FPGA -> UART -> MATLAB: REF + U
%
% MATLAB -> FPGA:
%   A5 | Y_H | Y_L
%
% FPGA -> MATLAB:
%   5A | REF_H | REF_L | U

clear; clc; close all;

%% 1. COM
COM_PORT = 'COM3';
BAUD = 115200;

%% 2. Diskretni model
Ts   = 0.01;
Tsim = 8.0;

t = (0:Ts:Tsim)';
N = length(t);

Kmot = 23.6083;    % rpm/V
tau  = 0.3022;     % s

a = exp(-Ts/tau);
b = Kmot*(1-a);

fprintf('Diskretni model: y(k+1) = %.8f*y(k) + %.8f*uV(k)\n', a, b);

%% 3. Skaliranje
Y_MAX_RPM = 300.0;
ADC_MAX   = 4095;
U_MAX     = 255;
U_MAX_V   = 10.0;

fprintf('Potenciometar: 0..4095 -> 0..%.1f rpm\n', Y_MAX_RPM);
fprintf('PID izlaz: 0..255 -> PWM duty 0..100 %%\n');
fprintf('Za prvi test postavi potenciometar otprilike na sredinu.\n\n');

%% 4. Ocisti eventualni stari serial objekat
try
    old = instrfind('Port', COM_PORT);

    if ~isempty(old)
        fclose(old);
        delete(old);
    end
catch
end

%% 5. Otvori UART
s = serial(COM_PORT, ...
    'BaudRate', BAUD, ...
    'DataBits', 8, ...
    'Parity', 'none', ...
    'StopBits', 1, ...
    'Timeout', 2);

fopen(s);
flushinput(s);
flushoutput(s);

% ADC u FPGA se osvjezava svaka ~0.25 s.
% Sacekaj da barem prvo mjerenje sigurno stigne.
pause(0.6);

%% 6. Memorija
r_rpm      = zeros(N,1);
r_count    = zeros(N,1);
y_rpm      = zeros(N,1);
y_count    = zeros(N,1);
u_byte     = zeros(N,1);
u_volt     = zeros(N,1);
pwm_duty   = zeros(N,1);
error_rpm  = zeros(N,1);
wall_t     = zeros(N,1);

y = 0.0;

tic;

%% 7. Zatvorena petlja
try

    for k = 1:N

        % MATLAB model -> 12-bitna povratna informacija
        meas_rpm = min(max(y,0),Y_MAX_RPM);

        meas_count = uint16( ...
            round(meas_rpm / Y_MAX_RPM * ADC_MAX) ...
        );

        % MATLAB -> FPGA: A5 Y_H Y_L
        packet = uint8([ ...
            hex2dec('A5'), ...
            bitshift(meas_count,-8), ...
            bitand(meas_count,uint16(255)) ...
        ]);

        fwrite(s, packet, 'uint8');


        % --------------------------------------------
        % Trazi header 0x5A
        % --------------------------------------------

        header_found = 0;
        t_wait = tic;

        while header_found == 0

            if s.BytesAvailable > 0

                b_rx = fread(s,1,'uint8');

                if b_rx == hex2dec('5A')
                    header_found = 1;
                end

            else

                pause(0.0005);

            end


            if toc(t_wait) > 2

                error('Timeout: FPGA nije poslao 0x5A.');

            end

        end


        % --------------------------------------------
        % REF_H REF_L U
        % --------------------------------------------

        t_wait = tic;

        while s.BytesAvailable < 3

            pause(0.0005);

            if toc(t_wait) > 2

                error('Timeout: nepotpun FPGA odgovor.');

            end

        end


        resp = fread(s,3,'uint8');

        ref_count = ...
            double(resp(1))*256 + double(resp(2));

        u = double(resp(3));


        if ref_count > ADC_MAX
            ref_count = ADC_MAX;
        end


        % --------------------------------------------
        % Fizicke interpretacije
        % --------------------------------------------

        ref_rpm = ...
            ref_count / ADC_MAX * Y_MAX_RPM;

        uv = ...
            u / U_MAX * U_MAX_V;

        duty = ...
            100.0 * u / U_MAX;


        % --------------------------------------------
        % MATLAB model motora
        % --------------------------------------------

        y_next = ...
            a*y + b*uv;


        % --------------------------------------------
        % Logovanje
        % --------------------------------------------

        r_count(k)   = ref_count;
        r_rpm(k)     = ref_rpm;

        y_rpm(k)     = y;
        y_count(k)   = double(meas_count);

        u_byte(k)    = u;
        u_volt(k)    = uv;
        pwm_duty(k)  = duty;

        error_rpm(k) = ref_rpm - y;

        wall_t(k)    = toc;

        y = y_next;


        if mod(k,25) == 0

            fprintf([ ...
                'k=%4d, t_sim=%5.2f s, REF=%4.0f, ' ...
                'r=%6.1f rpm, y=%6.1f rpm, ' ...
                'u=%3.0f, PWM=%5.1f %%\n' ...
                ], ...
                k, t(k), ...
                ref_count, ...
                ref_rpm, ...
                y_rpm(k), ...
                u_byte(k), ...
                pwm_duty(k));

        end

    end


catch ME

    if strcmp(s.Status,'open')
        fclose(s);
    end

    delete(s);
    clear s;

    rethrow(ME);

end


%% 8. Zatvori UART
fclose(s);
delete(s);
clear s;


%% 9. Grafovi

figure;
plot(t, r_rpm, 'LineWidth', 1.5);
hold on;
plot(t, y_rpm, 'LineWidth', 1.5);
grid on;

xlabel('Simulirano vrijeme [s]');
ylabel('Brzina [rpm]');

legend( ...
    'Referenca r(k) - potenciometar', ...
    'Izlaz modela y(k)' ...
);

title('ULX3S PID: pracenje reference zadate potenciometrom');


figure;
plot(t, error_rpm, 'LineWidth', 1.5);
grid on;

xlabel('Simulirano vrijeme [s]');
ylabel('Greska [rpm]');
title('Greska pracenja');


figure;
plot(t, u_byte, 'LineWidth', 1.5);
grid on;

xlabel('Simulirano vrijeme [s]');
ylabel('PID izlaz u(k) [0..255]');
title('Upravljacka vrijednost izracunata na FPGA');


figure;
plot(t, pwm_duty, 'LineWidth', 1.5);
grid on;

xlabel('Simulirano vrijeme [s]');
ylabel('Faktor ispunjenosti [%]');
title('PWM faktor ispunjenosti');


figure;
plot(t, r_count, 'LineWidth', 1.5);
grid on;

xlabel('Simulirano vrijeme [s]');
ylabel('ADC referenca [0..4095]');
title('MAX11125 AIN0 - fizicka referenca');


%% 10. Stvarno vrijeme komunikacije
if N > 1

    fprintf('\nProsjecno stvarno trajanje jedne UART iteracije: %.3f ms\n', ...
        1000*mean(diff(wall_t)));

end
