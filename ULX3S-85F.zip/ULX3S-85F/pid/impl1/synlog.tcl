run_tcl -fg pid_impl1_synplify.tcl
