library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity uart_rx is

    generic (
        CLK_FREQ  : positive := 25000000;
        BAUD_RATE : positive := 115200
    );

    Port (
        clk        : in  STD_LOGIC;
        reset      : in  STD_LOGIC;
        rx         : in  STD_LOGIC;

        data_out   : out STD_LOGIC_VECTOR(7 downto 0);
        data_valid : out STD_LOGIC
    );

end uart_rx;


architecture Behavioral of uart_rx is

    constant CLKS_PER_BIT : positive :=
        CLK_FREQ / BAUD_RATE;

    type state_type is (
        IDLE,
        START_BIT,
        DATA_BITS,
        STOP_BIT
    );

    signal state : state_type := IDLE;

    -- Sinhronizacija asinhronog RX signala
    signal rx_sync1 : STD_LOGIC := '1';
    signal rx_sync2 : STD_LOGIC := '1';

    signal clk_counter :
        INTEGER range 0 to CLKS_PER_BIT-1 := 0;

    signal bit_index :
        INTEGER range 0 to 7 := 0;

    signal data_reg :
        STD_LOGIC_VECTOR(7 downto 0) := (others => '0');

    signal valid_reg : STD_LOGIC := '0';

begin


    --------------------------------------------------
    -- SINHRONIZACIJA RX ULAZA
    --------------------------------------------------

    process(clk)
    begin

        if rising_edge(clk) then

            if reset = '1' then

                rx_sync1 <= '1';
                rx_sync2 <= '1';

            else

                rx_sync1 <= rx;
                rx_sync2 <= rx_sync1;

            end if;

        end if;

    end process;


    --------------------------------------------------
    -- UART RECEIVER
    --------------------------------------------------

    process(clk)
    begin

        if rising_edge(clk) then

            if reset = '1' then

                state       <= IDLE;
                clk_counter <= 0;
                bit_index   <= 0;
                data_reg    <= (others => '0');
                valid_reg   <= '0';

            else

                -- data_valid traje samo jedan takt
                valid_reg <= '0';


                case state is


                    ----------------------------------
                    -- CEKANJE START BITA
                    ----------------------------------

                    when IDLE =>

                        clk_counter <= 0;
                        bit_index   <= 0;

                        if rx_sync2 = '0' then

                            state <= START_BIT;

                        end if;


                    ----------------------------------
                    -- PROVJERA SREDINE START BITA
                    ----------------------------------

                    when START_BIT =>

                        if clk_counter =
                           (CLKS_PER_BIT-1)/2 then

                            clk_counter <= 0;

                            -- Start bit jos uvijek mora biti 0
                            if rx_sync2 = '0' then

                                state <= DATA_BITS;

                            else

                                state <= IDLE;

                            end if;

                        else

                            clk_counter <= clk_counter + 1;

                        end if;


                    ----------------------------------
                    -- PRIJEM 8 PODATKOVNIH BITOVA
                    ----------------------------------

                    when DATA_BITS =>

                        if clk_counter =
                           CLKS_PER_BIT-1 then

                            clk_counter <= 0;

                            -- UART salje LSB prvi
                            data_reg(bit_index)
                                <= rx_sync2;

                            if bit_index = 7 then

                                bit_index <= 0;
                                state <= STOP_BIT;

                            else

                                bit_index <= bit_index + 1;

                            end if;

                        else

                            clk_counter <= clk_counter + 1;

                        end if;


                    ----------------------------------
                    -- STOP BIT
                    ----------------------------------

                    when STOP_BIT =>

                        if clk_counter =
                           CLKS_PER_BIT-1 then

                            clk_counter <= 0;

                            if rx_sync2 = '1' then

                                valid_reg <= '1';

                            end if;

                            state <= IDLE;

                        else

                            clk_counter <= clk_counter + 1;

                        end if;


                end case;

            end if;

        end if;

    end process;


    data_out   <= data_reg;
    data_valid <= valid_reg;


end Behavioral;