library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;



entity pid_pot_uart_pwm_final_top is
    port (
        clk_25m  : in  STD_LOGIC;
        btn_down : in  STD_LOGIC;

        -- USB UART
        rs232_rx : in  STD_LOGIC;
        rs232_tx : out STD_LOGIC;

        -- MAX11125 SPI
        adc_csn  : out STD_LOGIC;
        adc_mosi : out STD_LOGIC;
        adc_miso : in  STD_LOGIC;
        adc_sclk : out STD_LOGIC;

        -- LED indikatori
        led      : out STD_LOGIC_VECTOR(7 downto 0)
    );
end pid_pot_uart_pwm_final_top;


architecture Behavioral of pid_pot_uart_pwm_final_top is

    ------------------------------------------------------------
    -- ADC
    ------------------------------------------------------------

    signal adc_start : STD_LOGIC := '0';
    signal adc_busy  : STD_LOGIC := '0';
    signal adc_valid : STD_LOGIC := '0';

    signal adc_data :
        STD_LOGIC_VECTOR(11 downto 0)
        := (others => '0');

    -- AIN0
    signal adc_channel :
        STD_LOGIC_VECTOR(2 downto 0)
        := "000";

    -- Zadrzavamo potpuno isti, vec provjeren ADC ritam:
    -- 25 MHz * 0.25 s = 6 250 000 taktova
    signal adc_sample_counter :
        INTEGER range 0 to 6249999 := 0;

    signal reference_count :
        STD_LOGIC_VECTOR(11 downto 0)
        := (others => '0');

    signal adc_heartbeat :
        STD_LOGIC := '0';


    ------------------------------------------------------------
    -- UART RX
    ------------------------------------------------------------

    signal rx_data :
        STD_LOGIC_VECTOR(7 downto 0)
        := (others => '0');

    signal rx_valid :
        STD_LOGIC := '0';

    signal y_hi :
        STD_LOGIC_VECTOR(7 downto 0)
        := (others => '0');

    signal y_lo :
        STD_LOGIC_VECTOR(7 downto 0)
        := (others => '0');

    signal rx_index :
        INTEGER range 0 to 2 := 0;

    signal packet_ready :
        STD_LOGIC := '0';


    ------------------------------------------------------------
    -- PID
    ------------------------------------------------------------

    signal pid_error :
        INTEGER range -4095 to 4095 := 0;

    signal pid_start :
        STD_LOGIC := '0';

    signal pid_valid :
        STD_LOGIC := '0';

    signal pid_output :
        INTEGER range 0 to 255 := 0;

    signal pid_output_vector :
        UNSIGNED(7 downto 0)
        := (others => '0');


    type control_state_type is (
        CTRL_IDLE,
        CTRL_START_PID,
        CTRL_WAIT_PID
    );

    signal control_state :
        control_state_type := CTRL_IDLE;


    ------------------------------------------------------------
    -- PWM
    ------------------------------------------------------------

    signal pwm_signal :
        STD_LOGIC := '0';


    ------------------------------------------------------------
    -- Odgovor prema MATLAB-u
    ------------------------------------------------------------

    signal response_ref :
        STD_LOGIC_VECTOR(11 downto 0)
        := (others => '0');

    signal response_u :
        STD_LOGIC_VECTOR(7 downto 0)
        := (others => '0');

    signal response_pending :
        STD_LOGIC := '0';


    ------------------------------------------------------------
    -- UART TX
    ------------------------------------------------------------

    signal tx_data :
        STD_LOGIC_VECTOR(7 downto 0)
        := (others => '0');

    signal tx_start :
        STD_LOGIC := '0';

    signal tx_busy :
        STD_LOGIC := '0';

    type tx_state_type is (
        TX_IDLE,
        TX_LOAD,
        TX_WAIT_BUSY,
        TX_WAIT_DONE
    );

    signal tx_state :
        tx_state_type := TX_IDLE;

    signal tx_index :
        INTEGER range 0 to 3 := 0;


begin

    ------------------------------------------------------------
    -- LED dijagnostika
    ------------------------------------------------------------

    led(7) <= adc_heartbeat;

    led(6 downto 1) <=
        response_u(7 downto 2);

    led(0) <= pwm_signal;


    ------------------------------------------------------------
    -- Provjereni MAX11125 modul
    ------------------------------------------------------------

    ADC_MODULE :
        entity work.max11125_adc

        generic map (
            HALF_DIV => 12
        )

        port map (
            clk        => clk_25m,
            reset      => btn_down,

            start      => adc_start,
            channel    => adc_channel,

            adc_csn    => adc_csn,
            adc_mosi   => adc_mosi,
            adc_miso   => adc_miso,
            adc_sclk   => adc_sclk,

            adc_value  => adc_data,
            data_valid => adc_valid,
            busy       => adc_busy
        );


    ------------------------------------------------------------
    -- TACNO korisnicin provjereni uart_rx
    ------------------------------------------------------------

    UART_RX_MODULE :
        entity work.uart_rx

        generic map (
            CLK_FREQ  => 25000000,
            BAUD_RATE => 115200
        )

        port map (
            clk        => clk_25m,
            reset      => btn_down,
            rx         => rs232_rx,

            data_out   => rx_data,
            data_valid => rx_valid
        );


    ------------------------------------------------------------
    -- PID
    ------------------------------------------------------------

    PID_MODULE :
        entity work.pid_core

        port map (
            clk         => clk_25m,
            reset       => btn_down,

            sample_en   => pid_start,
            error_in    => pid_error,

            control_out => pid_output,
            data_valid  => pid_valid
        );


    ------------------------------------------------------------
    -- PWM: PID izlaz 0..255 = duty_cycle 0..255
    ------------------------------------------------------------

    pid_output_vector <=
        to_unsigned(pid_output, 8);


    PWM_MODULE :
        entity work.pwm_core

        generic map (
            PWM_BITS    => 8,
            CLK_CNT_LEN => 5
        )

        port map (
            clk        => clk_25m,
            reset      => btn_down,

            duty_cycle => pid_output_vector,
            pwm_out    => pwm_signal
        );


    ------------------------------------------------------------
    -- TACNO korisnicin provjereni uart_tx
    ------------------------------------------------------------

    UART_TX_MODULE :
        entity work.uart_tx

        generic map (
            CLK_FREQ  => 25000000,
            BAUD_RATE => 115200
        )

        port map (
            clk      => clk_25m,
            reset    => btn_down,

            data_in  => tx_data,
            tx_start => tx_start,

            tx       => rs232_tx,
            tx_busy  => tx_busy
        );


    ------------------------------------------------------------
    -- 1. ADC PROCES
    --
    -- Ostaje nezavisan od UART/PID logike.
    -- Isti princip i isti period kao test koji je vec radio.
    ------------------------------------------------------------

    process(clk_25m)
    begin

        if rising_edge(clk_25m) then

            adc_start <= '0';

            if btn_down = '1' then

                adc_sample_counter <= 0;

                reference_count <=
                    (others => '0');

                adc_heartbeat <=
                    '0';


            else

                if adc_sample_counter = 6249999 then

                    adc_sample_counter <= 0;

                    if adc_busy = '0' then

                        adc_start <= '1';

                    end if;

                else

                    adc_sample_counter <=
                        adc_sample_counter + 1;

                end if;


                if adc_valid = '1' then

                    reference_count <=
                        adc_data;

                    adc_heartbeat <=
                        not adc_heartbeat;

                end if;

            end if;

        end if;

    end process;


    ------------------------------------------------------------
    -- 2. UART RX:
    -- MATLAB -> FPGA = A5 | Y_H | Y_L
    ------------------------------------------------------------

    process(clk_25m)
    begin

        if rising_edge(clk_25m) then

            packet_ready <= '0';

            if btn_down = '1' then

                rx_index <= 0;

                y_hi <=
                    (others => '0');

                y_lo <=
                    (others => '0');


            elsif rx_valid = '1' then

                case rx_index is


                    when 0 =>

                        if rx_data = x"A5" then

                            rx_index <= 1;

                        else

                            rx_index <= 0;

                        end if;


                    when 1 =>

                        y_hi <= rx_data;

                        rx_index <= 2;


                    when 2 =>

                        y_lo <= rx_data;

                        packet_ready <= '1';

                        rx_index <= 0;


                end case;

            end if;

        end if;

    end process;


    ------------------------------------------------------------
    -- 3. PID CONTROL
    --
    -- Nakon primljenog y(k):
    --   e(k) = r(k) - y(k)
    --   pokreni PID
    --   zapamti REF i U za jedan konzistentan UART odgovor
    ------------------------------------------------------------

    process(clk_25m)

        variable r_tmp :
            INTEGER;

        variable y_tmp :
            INTEGER;

        variable e_tmp :
            INTEGER;

    begin

        if rising_edge(clk_25m) then

            pid_start <= '0';

            response_pending <= '0';


            if btn_down = '1' then

                control_state <=
                    CTRL_IDLE;

                pid_error <=
                    0;

                response_ref <=
                    (others => '0');

                response_u <=
                    (others => '0');


            else

                case control_state is


                    when CTRL_IDLE =>

                        if packet_ready = '1' then

                            r_tmp :=
                                to_integer(
                                    unsigned(reference_count)
                                );

                            y_tmp :=
                                to_integer(
                                    unsigned(y_hi & y_lo)
                                );


                            -- Bezbijedno ogranicenje 12-bitnog opsega

                            if r_tmp > 4095 then
                                r_tmp := 4095;
                            end if;

                            if y_tmp > 4095 then
                                y_tmp := 4095;
                            end if;


                            e_tmp :=
                                r_tmp - y_tmp;

                            pid_error <=
                                e_tmp;


                            -- PID sample_en ide tek u sljedecem taktu,
                            -- tako da je pid_error tada vec stabilan.

                            control_state <=
                                CTRL_START_PID;

                        end if;


                    when CTRL_START_PID =>

                        pid_start <= '1';

                        control_state <=
                            CTRL_WAIT_PID;


                    when CTRL_WAIT_PID =>

                        if pid_valid = '1' then

                            response_ref <=
                                reference_count;

                            response_u <=
                                std_logic_vector(
                                    to_unsigned(pid_output, 8)
                                );

                            response_pending <=
                                '1';

                            control_state <=
                                CTRL_IDLE;

                        end if;


                end case;

            end if;

        end if;

    end process;


    ------------------------------------------------------------
    -- 4. UART TX:
    -- FPGA -> MATLAB = 5A | REF_H | REF_L | U
    ------------------------------------------------------------

    process(clk_25m)
    begin

        if rising_edge(clk_25m) then

            tx_start <= '0';


            if btn_down = '1' then

                tx_state <=
                    TX_IDLE;

                tx_index <=
                    0;

                tx_data <=
                    (others => '0');


            else

                case tx_state is


                    when TX_IDLE =>

                        if response_pending = '1' then

                            tx_index <= 0;

                            tx_state <=
                                TX_LOAD;

                        end if;


                    when TX_LOAD =>

                        if tx_busy = '0' then

                            case tx_index is

                                when 0 =>

                                    tx_data <=
                                        x"5A";


                                when 1 =>

                                    tx_data <=
                                        "0000" &
                                        response_ref(11 downto 8);


                                when 2 =>

                                    tx_data <=
                                        response_ref(7 downto 0);


                                when 3 =>

                                    tx_data <=
                                        response_u;


                            end case;


                            tx_start <=
                                '1';

                            tx_state <=
                                TX_WAIT_BUSY;

                        end if;


                    when TX_WAIT_BUSY =>

                        if tx_busy = '1' then

                            tx_state <=
                                TX_WAIT_DONE;

                        end if;


                    when TX_WAIT_DONE =>

                        if tx_busy = '0' then

                            if tx_index = 3 then

                                tx_state <=
                                    TX_IDLE;

                            else

                                tx_index <=
                                    tx_index + 1;

                                tx_state <=
                                    TX_LOAD;

                            end if;

                        end if;


                end case;

            end if;

        end if;

    end process;


end Behavioral;
