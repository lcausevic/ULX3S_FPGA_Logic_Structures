library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity pid_core is
    port (
        clk         : in  STD_LOGIC;
        reset       : in  STD_LOGIC;
        sample_en   : in  STD_LOGIC;
        error_in    : in  INTEGER range -4095 to 4095;
        control_out : out INTEGER range 0 to 255;
        data_valid  : out STD_LOGIC
    );
end pid_core;

architecture Behavioral of pid_core is
    constant SCALE : INTEGER := 16;
    constant K1 : INTEGER := 3;
    constant K2 : INTEGER := -2;
    constant K3 : INTEGER := 0;

    signal e_prev1 : INTEGER range -4095 to 4095 := 0;
    signal e_prev2 : INTEGER range -4095 to 4095 := 0;
    signal u_accum : INTEGER range 0 to 4080 := 0;
    signal control_reg : INTEGER range 0 to 255 := 0;
    signal valid_reg : STD_LOGIC := '0';
begin
    control_out <= control_reg;
    data_valid  <= valid_reg;

    process(clk)
        variable u_temp : INTEGER;
    begin
        if rising_edge(clk) then
            valid_reg <= '0';

            if reset = '1' then
                e_prev1    <= 0;
                e_prev2    <= 0;
                u_accum    <= 0;
                control_reg <= 0;
                valid_reg   <= '0';

            elsif sample_en = '1' then
                u_temp := u_accum
                          + K1 * error_in
                          + K2 * e_prev1
                          + K3 * e_prev2;

                if u_temp > 4080 then
                    u_accum     <= 4080;
                    control_reg <= 255;
                elsif u_temp < 0 then
                    u_accum     <= 0;
                    control_reg <= 0;
                else
                    u_accum     <= u_temp;
                    control_reg <= u_temp / SCALE;
                end if;

                e_prev2 <= e_prev1;
                e_prev1 <= error_in;
                valid_reg <= '1';
            end if;
        end if;
    end process;
end Behavioral;
