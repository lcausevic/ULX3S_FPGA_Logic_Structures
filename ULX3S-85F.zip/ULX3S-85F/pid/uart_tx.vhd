library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity uart_tx is

    generic (
        CLK_FREQ  : positive := 25000000;
        BAUD_RATE : positive := 115200
    );

    Port (
        clk      : in  STD_LOGIC;
        reset    : in  STD_LOGIC;

        data_in  : in  STD_LOGIC_VECTOR(7 downto 0);
        tx_start : in  STD_LOGIC;

        tx       : out STD_LOGIC;
        tx_busy  : out STD_LOGIC
    );

end uart_tx;


architecture Behavioral of uart_tx is

    constant CLKS_PER_BIT : positive :=
        CLK_FREQ / BAUD_RATE;

    type state_type is (
        IDLE,
        START_BIT,
        DATA_BITS,
        STOP_BIT
    );

    signal state : state_type := IDLE;

    signal clk_counter :
        INTEGER range 0 to CLKS_PER_BIT-1 := 0;

    signal bit_index :
        INTEGER range 0 to 7 := 0;

    signal data_reg :
        STD_LOGIC_VECTOR(7 downto 0) := (others => '0');

    signal tx_reg : STD_LOGIC := '1';

begin


    process(clk)
    begin

        if rising_edge(clk) then

            if reset = '1' then

                state       <= IDLE;
                clk_counter <= 0;
                bit_index   <= 0;
                data_reg    <= (others => '0');
                tx_reg      <= '1';

            else


                case state is


                    ----------------------------------
                    -- IDLE
                    ----------------------------------

                    when IDLE =>

                        tx_reg      <= '1';
                        clk_counter <= 0;
                        bit_index   <= 0;

                        if tx_start = '1' then

                            data_reg <= data_in;
                            state <= START_BIT;

                        end if;


                    ----------------------------------
                    -- START BIT = 0
                    ----------------------------------

                    when START_BIT =>

                        tx_reg <= '0';

                        if clk_counter =
                           CLKS_PER_BIT-1 then

                            clk_counter <= 0;
                            state <= DATA_BITS;

                        else

                            clk_counter <= clk_counter + 1;

                        end if;


                    ----------------------------------
                    -- DATA BITOVI
                    ----------------------------------

                    when DATA_BITS =>

                        tx_reg <= data_reg(bit_index);

                        if clk_counter =
                           CLKS_PER_BIT-1 then

                            clk_counter <= 0;

                            if bit_index = 7 then

                                bit_index <= 0;
                                state <= STOP_BIT;

                            else

                                bit_index <= bit_index + 1;

                            end if;

                        else

                            clk_counter <= clk_counter + 1;

                        end if;


                    ----------------------------------
                    -- STOP BIT = 1
                    ----------------------------------

                    when STOP_BIT =>

                        tx_reg <= '1';

                        if clk_counter =
                           CLKS_PER_BIT-1 then

                            clk_counter <= 0;
                            state <= IDLE;

                        else

                            clk_counter <= clk_counter + 1;

                        end if;


                end case;

            end if;

        end if;

    end process;


    tx <= tx_reg;

    tx_busy <= '0' when state = IDLE
               else '1';


end Behavioral;