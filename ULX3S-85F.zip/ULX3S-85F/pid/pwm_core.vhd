library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity pwm_core is
    generic (
        PWM_BITS    : positive := 8;
        CLK_CNT_LEN : positive := 5
    );

    Port (
        clk        : in  STD_LOGIC;
        reset      : in  STD_LOGIC;
        duty_cycle : in  UNSIGNED(PWM_BITS-1 downto 0);
        pwm_out    : out STD_LOGIC
    );
end pwm_core;


architecture Behavioral of pwm_core is

    signal pwm_counter :
        UNSIGNED(PWM_BITS-1 downto 0) := (others => '0');

    signal clk_counter :
        INTEGER range 0 to CLK_CNT_LEN-1 := 0;

    constant PWM_MAX_MINUS_ONE :
        UNSIGNED(PWM_BITS-1 downto 0) :=
        to_unsigned((2**PWM_BITS)-2, PWM_BITS);

begin

    process(clk)
    begin

        if rising_edge(clk) then

            if reset = '1' then

                pwm_counter <= (others => '0');
                clk_counter <= 0;
                pwm_out     <= '0';

            else

                -- Clock enable
                if clk_counter = CLK_CNT_LEN-1 then

                    clk_counter <= 0;

                    -- PWM izlaz
                    if pwm_counter < duty_cycle then
                        pwm_out <= '1';
                    else
                        pwm_out <= '0';
                    end if;

                    -- PWM brojac ide od 0 do 2^PWM_BITS - 2
                    if pwm_counter = PWM_MAX_MINUS_ONE then
                        pwm_counter <= (others => '0');
                    else
                        pwm_counter <= pwm_counter + 1;
                    end if;

                else

                    clk_counter <= clk_counter + 1;

                end if;

            end if;

        end if;

    end process;

end Behavioral;