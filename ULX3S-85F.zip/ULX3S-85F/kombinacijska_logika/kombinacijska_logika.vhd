library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity kombinacijska_logika is
    Port (
        sw  : in  STD_LOGIC_VECTOR(3 downto 0);
        led : out STD_LOGIC_VECTOR(7 downto 0)
    );
end kombinacijska_logika;

architecture Behavioral of kombinacijska_logika is

    signal A, B, C : STD_LOGIC;
    signal Y_original : STD_LOGIC;
    signal Y_min : STD_LOGIC;
    signal Y_nand : STD_LOGIC;

    signal nA   : STD_LOGIC;
    signal nBC  : STD_LOGIC;

begin

    -- Dodjela prekidaca ulaznim promjenljivim
    A <= sw(2);
    B <= sw(1);
    C <= sw(0);

    -- Originalna funkcija
    Y_original <= A OR (B AND C) OR (A AND (NOT C));

    -- Minimizirana funkcija
    Y_min <= A OR (B AND C);

    -- Realizacija iskljucivo NAND operacijama
    nA  <= A NAND A;
    nBC <= B NAND C;

    Y_nand <= nA NAND nBC;

    -- Prikaz rezultata
    led(0) <= Y_original;
    led(1) <= Y_min;
    led(2) <= Y_nand;

    -- Ostale LED diode se ne koriste
    led(7 downto 3) <= "00000";

end Behavioral;