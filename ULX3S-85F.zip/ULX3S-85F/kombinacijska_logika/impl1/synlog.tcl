run_tcl -fg kombinacijska_logika_impl1_synplify.tcl
