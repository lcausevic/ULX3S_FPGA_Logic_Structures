[ActiveSupport TRCE]
; Setup Analysis
Other_0 = 8.352 ns (0.000 ns);
Other_1 = 3.036 ns (0.000 ns);
Failed = 0 (Total 2);
Clock_ports = 0;
Clock_nets = 0;
