run_tcl -fg adc_impl1_synplify.tcl
