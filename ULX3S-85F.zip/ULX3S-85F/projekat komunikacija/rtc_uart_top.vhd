library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity rtc_uart_top is

    port (
        clk_25m   : in  STD_LOGIC;

        btn_up    : in  STD_LOGIC;
        btn_down  : in  STD_LOGIC;
        btn_left  : in  STD_LOGIC;
        btn_right : in  STD_LOGIC;
        btn_f1    : in  STD_LOGIC;
        btn_f2    : in  STD_LOGIC;

        -- I2C prema onboard MCP7940N RTC-u
        gpdi_sda  : inout STD_LOGIC;
        gpdi_scl  : inout STD_LOGIC;

        -- UART prema racunaru
        rs232_tx  : out STD_LOGIC;

        -- LED prikaz
        led       : out STD_LOGIC_VECTOR(7 downto 0)
    );

end rtc_uart_top;


architecture Behavioral of rtc_uart_top is

    subtype byte_t is STD_LOGIC_VECTOR(7 downto 0);


    ----------------------------------------------------------------
    -- Pretvaranje cijelog broja u BCD
    --
    -- npr. 37 -> 0011 0111 = 0x37
    ----------------------------------------------------------------

    function int_to_bcd (
        value : integer
    ) return byte_t is

        variable tens :
            integer range 0 to 9;

        variable ones :
            integer range 0 to 9;

        variable result :
            byte_t;

    begin

        tens := value / 10;
        ones := value mod 10;

        result(7 downto 4) :=
            STD_LOGIC_VECTOR(
                to_unsigned(tens, 4)
            );

        result(3 downto 0) :=
            STD_LOGIC_VECTOR(
                to_unsigned(ones, 4)
            );

        return result;

    end function;


    ----------------------------------------------------------------
    -- BCD -> integer
    ----------------------------------------------------------------

    function bcd_to_int (
        value : byte_t
    ) return integer is

        variable tens :
            integer;

        variable ones :
            integer;

    begin

        tens :=
            to_integer(
                unsigned(value(7 downto 4))
            );

        ones :=
            to_integer(
                unsigned(value(3 downto 0))
            );

        return tens * 10 + ones;

    end function;


    ----------------------------------------------------------------
    -- BCD cifra -> ASCII
    --
    -- 3 -> ASCII '3' = 0x33
    ----------------------------------------------------------------

    function bcd_digit_to_ascii (
        digit : STD_LOGIC_VECTOR(3 downto 0)
    ) return byte_t is

        variable result :
            byte_t;

    begin

        result := "0011" & digit;

        return result;

    end function;


    ----------------------------------------------------------------
    -- 0 = sekunde
    -- 1 = minute
    -- 2 = sati
    ----------------------------------------------------------------

    signal izbor :
        integer range 0 to 2 := 0;


    ----------------------------------------------------------------
    -- SET MODE
    ----------------------------------------------------------------

    signal set_mode :
        STD_LOGIC := '0';

    signal set_request :
        STD_LOGIC := '0';

    signal set_field :
        integer range 0 to 2 := 2;

    signal set_seconds :
        integer range 0 to 59 := 0;

    signal set_minutes :
        integer range 0 to 59 := 0;

    signal set_hours :
        integer range 0 to 23 := 0;


    signal set_seconds_bcd :
        byte_t;

    signal set_minutes_bcd :
        byte_t;

    signal set_hours_bcd :
        byte_t;


    ----------------------------------------------------------------
    -- I2C master
    ----------------------------------------------------------------

    signal master_start :
        STD_LOGIC := '0';

    signal master_read_op :
        STD_LOGIC := '1';

    signal master_reg_addr :
        byte_t := x"00";

    signal master_write_data :
        byte_t := x"00";

    signal master_read_data :
        byte_t := x"00";

    signal master_busy :
        STD_LOGIC;

    signal master_done :
        STD_LOGIC;

    signal master_error :
        STD_LOGIC;


    ----------------------------------------------------------------
    -- RTC podaci
    ----------------------------------------------------------------

    signal rtc_seconds :
        byte_t := x"00";

    signal rtc_minutes :
        byte_t := x"00";

    signal rtc_hours :
        byte_t := x"00";


    signal error_latched :
        STD_LOGIC := '0';


    ----------------------------------------------------------------
    -- Tajmeri
    ----------------------------------------------------------------

    signal startup_counter :
        integer range 0 to 2499999 := 0;

    signal second_counter :
        integer range 0 to 24999999 := 0;

    signal button_lock :
        integer range 0 to 2499999 := 0;


    ----------------------------------------------------------------
    -- Prethodna stanja tipki
    ----------------------------------------------------------------

    signal up_old :
        STD_LOGIC := '0';

    signal left_old :
        STD_LOGIC := '0';

    signal right_old :
        STD_LOGIC := '0';

    signal f1_old :
        STD_LOGIC := '0';

    signal f2_old :
        STD_LOGIC := '0';


    ----------------------------------------------------------------
    -- Blink za prikaz sati
    ----------------------------------------------------------------

    signal blink_counter :
        integer range 0 to 12499999 := 0;

    signal blink_state :
        STD_LOGIC := '0';


    ----------------------------------------------------------------
    -- Brzi blink u SET modu
    ----------------------------------------------------------------

    signal set_blink_counter :
        integer range 0 to 6249999 := 0;

    signal set_blink_state :
        STD_LOGIC := '0';


    ----------------------------------------------------------------
    -- UART
    ----------------------------------------------------------------

    constant CLKS_PER_BIT :
        integer := 217;

    signal uart_start :
        STD_LOGIC := '0';

    signal uart_byte :
        byte_t := x"00";

    signal uart_busy :
        STD_LOGIC := '0';

    signal uart_done :
        STD_LOGIC := '0';

    signal uart_tx_reg :
        STD_LOGIC := '1';

    signal uart_buffer :
        byte_t := x"00";

    signal uart_clk_counter :
        integer range 0 to CLKS_PER_BIT - 1 := 0;

    signal uart_bit_index :
        integer range 0 to 7 := 0;


    type uart_state_type is (
        UART_IDLE,
        UART_START_BIT,
        UART_DATA_BITS,
        UART_STOP_BIT
    );

    signal uart_state :
        uart_state_type := UART_IDLE;


    ----------------------------------------------------------------
    -- TIME: HH:MM:SS CR LF
    ----------------------------------------------------------------

    signal message_index :
        integer range 0 to 15 := 0;


    ----------------------------------------------------------------
    -- Glavni FSM
    ----------------------------------------------------------------

    type main_state_type is (

        WAIT_STARTUP,

        CHECK_ST_START,
        CHECK_ST_WAIT,

        START_RTC_START,
        START_RTC_WAIT,

        WAIT_ONE_SECOND,

        READ_HOURS_START,
        READ_HOURS_WAIT,

        READ_MINUTES_START,
        READ_MINUTES_WAIT,

        READ_SECONDS_START,
        READ_SECONDS_WAIT,

        UART_MESSAGE_START,
        UART_SEND_BYTE,
        UART_WAIT_BYTE,

        SET_IDLE,

        WRITE_HOURS_START,
        WRITE_HOURS_WAIT,

        WRITE_MINUTES_START,
        WRITE_MINUTES_WAIT,

        WRITE_SECONDS_START,
        WRITE_SECONDS_WAIT

    );

    signal main_state :
        main_state_type := WAIT_STARTUP;


begin


    ----------------------------------------------------------------
    -- SET vrijednosti -> BCD
    ----------------------------------------------------------------

    set_seconds_bcd <=
        int_to_bcd(set_seconds);

    set_minutes_bcd <=
        int_to_bcd(set_minutes);

    set_hours_bcd <=
        int_to_bcd(set_hours);


    ----------------------------------------------------------------
    -- I2C master
    ----------------------------------------------------------------

    RTC_I2C_MASTER :
        entity work.i2c_rtc_master

        generic map (
            TICK_DIV => 62
        )

        port map (

            clk        => clk_25m,
            reset      => btn_down,

            start      => master_start,
            read_op    => master_read_op,

            reg_addr   => master_reg_addr,
            write_data => master_write_data,

            read_data  => master_read_data,

            busy       => master_busy,
            done       => master_done,
            ack_error  => master_error,

            sda        => gpdi_sda,
            scl        => gpdi_scl

        );


    ----------------------------------------------------------------
    -- UART izlaz
    ----------------------------------------------------------------

    rs232_tx <= uart_tx_reg;


    ----------------------------------------------------------------
    -- UART transmitter
    ----------------------------------------------------------------

    process(clk_25m)
    begin

        if rising_edge(clk_25m) then

            uart_done <= '0';

            if btn_down = '1' then

                uart_state <= UART_IDLE;

                uart_tx_reg <= '1';

                uart_busy <= '0';

                uart_clk_counter <= 0;
                uart_bit_index <= 0;

                uart_buffer <= x"00";

            else

                case uart_state is


                    when UART_IDLE =>

                        uart_tx_reg <= '1';
                        uart_busy <= '0';

                        uart_clk_counter <= 0;

                        if uart_start = '1' then

                            uart_buffer <= uart_byte;

                            uart_tx_reg <= '0';

                            uart_busy <= '1';

                            uart_state <=
                                UART_START_BIT;

                        end if;


                    when UART_START_BIT =>

                        uart_busy <= '1';

                        if uart_clk_counter =
                           CLKS_PER_BIT - 1 then

                            uart_clk_counter <= 0;

                            uart_bit_index <= 0;

                            uart_tx_reg <=
                                uart_buffer(0);

                            uart_state <=
                                UART_DATA_BITS;

                        else

                            uart_clk_counter <=
                                uart_clk_counter + 1;

                        end if;


                    when UART_DATA_BITS =>

                        uart_busy <= '1';

                        if uart_clk_counter =
                           CLKS_PER_BIT - 1 then

                            uart_clk_counter <= 0;

                            if uart_bit_index = 7 then

                                uart_tx_reg <= '1';

                                uart_state <=
                                    UART_STOP_BIT;

                            else

                                uart_bit_index <=
                                    uart_bit_index + 1;

                                uart_tx_reg <=
                                    uart_buffer(
                                        uart_bit_index + 1
                                    );

                            end if;

                        else

                            uart_clk_counter <=
                                uart_clk_counter + 1;

                        end if;


                    when UART_STOP_BIT =>

                        uart_busy <= '1';

                        uart_tx_reg <= '1';

                        if uart_clk_counter =
                           CLKS_PER_BIT - 1 then

                            uart_clk_counter <= 0;

                            uart_busy <= '0';

                            uart_done <= '1';

                            uart_state <= UART_IDLE;

                        else

                            uart_clk_counter <=
                                uart_clk_counter + 1;

                        end if;


                    when others =>

                        uart_state <= UART_IDLE;

                end case;

            end if;

        end if;

    end process;


    ----------------------------------------------------------------
    -- Formiranje UART poruke
    --
    -- TIME: HH:MM:SS
    ----------------------------------------------------------------

    process(
        message_index,
        rtc_hours,
        rtc_minutes,
        rtc_seconds
    )
    begin

        case message_index is

            when 0 =>
                uart_byte <= x"54";     -- T

            when 1 =>
                uart_byte <= x"49";     -- I

            when 2 =>
                uart_byte <= x"4D";     -- M

            when 3 =>
                uart_byte <= x"45";     -- E

            when 4 =>
                uart_byte <= x"3A";     -- :

            when 5 =>
                uart_byte <= x"20";     -- space


            -- HH
            when 6 =>
                uart_byte <=
                    bcd_digit_to_ascii(
                        "00" &
                        rtc_hours(5 downto 4)
                    );

            when 7 =>
                uart_byte <=
                    bcd_digit_to_ascii(
                        rtc_hours(3 downto 0)
                    );


            when 8 =>
                uart_byte <= x"3A";


            -- MM
            when 9 =>
                uart_byte <=
                    bcd_digit_to_ascii(
                        '0' &
                        rtc_minutes(6 downto 4)
                    );

            when 10 =>
                uart_byte <=
                    bcd_digit_to_ascii(
                        rtc_minutes(3 downto 0)
                    );


            when 11 =>
                uart_byte <= x"3A";


            -- SS
            when 12 =>
                uart_byte <=
                    bcd_digit_to_ascii(
                        '0' &
                        rtc_seconds(6 downto 4)
                    );

            when 13 =>
                uart_byte <=
                    bcd_digit_to_ascii(
                        rtc_seconds(3 downto 0)
                    );


            when 14 =>
                uart_byte <= x"0D";     -- CR

            when 15 =>
                uart_byte <= x"0A";     -- LF


            when others =>
                uart_byte <= x"20";

        end case;

    end process;


    ----------------------------------------------------------------
    -- Blink generator
    ----------------------------------------------------------------

    process(clk_25m)
    begin

        if rising_edge(clk_25m) then

            if btn_down = '1' then

                blink_counter <= 0;
                blink_state <= '0';

            else

                if blink_counter = 12499999 then

                    blink_counter <= 0;

                    blink_state <=
                        NOT blink_state;

                else

                    blink_counter <=
                        blink_counter + 1;

                end if;

            end if;

        end if;

    end process;


    ----------------------------------------------------------------
    -- SET blink
    ----------------------------------------------------------------

    process(clk_25m)
    begin

        if rising_edge(clk_25m) then

            if btn_down = '1' then

                set_blink_counter <= 0;
                set_blink_state <= '1';

            else

                if set_blink_counter = 6249999 then

                    set_blink_counter <= 0;

                    set_blink_state <=
                        NOT set_blink_state;

                else

                    set_blink_counter <=
                        set_blink_counter + 1;

                end if;

            end if;

        end if;

    end process;


    ----------------------------------------------------------------
    -- Glavni proces
    ----------------------------------------------------------------

    process(clk_25m)
    begin

        if rising_edge(clk_25m) then


            --------------------------------------------------------
            -- start impulsi
            --------------------------------------------------------

            master_start <= '0';
            uart_start <= '0';


            --------------------------------------------------------
            -- pamcenje prethodnog stanja tipki
            --------------------------------------------------------

            up_old <= btn_up;
            left_old <= btn_left;
            right_old <= btn_right;

            f1_old <= btn_f1;
            f2_old <= btn_f2;


            --------------------------------------------------------
            -- RESET
            --------------------------------------------------------

            if btn_down = '1' then

                izbor <= 0;

                set_mode <= '0';
                set_request <= '0';

                set_field <= 2;

                set_seconds <= 0;
                set_minutes <= 0;
                set_hours <= 0;

                master_start <= '0';
                master_read_op <= '1';

                master_reg_addr <= x"00";
                master_write_data <= x"00";

                rtc_seconds <= x"00";
                rtc_minutes <= x"00";
                rtc_hours <= x"00";

                error_latched <= '0';

                startup_counter <= 0;
                second_counter <= 0;

                button_lock <= 0;

                message_index <= 0;

                main_state <= WAIT_STARTUP;


            else


                ----------------------------------------------------
                -- Debounce
                ----------------------------------------------------

                if button_lock > 0 then

                    button_lock <=
                        button_lock - 1;

                end if;


                ----------------------------------------------------
                -- NORMALNI REZIM
                ----------------------------------------------------

                if (set_mode = '0') and
                   (button_lock = 0) then


                    ----------------------------------------------
                    -- UP -> zahtjev za SET mode
                    ----------------------------------------------

                    if (btn_up = '1') and
                       (up_old = '0') then

                        set_request <= '1';

                        button_lock <= 2499999;


                    ----------------------------------------------
                    -- RIGHT -> sljedeci prikaz
                    ----------------------------------------------

                    elsif (btn_right = '1') and
                          (right_old = '0') then

                        if izbor = 2 then
                            izbor <= 0;
                        else
                            izbor <= izbor + 1;
                        end if;

                        button_lock <= 2499999;


                    ----------------------------------------------
                    -- LEFT -> prethodni prikaz
                    ----------------------------------------------

                    elsif (btn_left = '1') and
                          (left_old = '0') then

                        if izbor = 0 then
                            izbor <= 2;
                        else
                            izbor <= izbor - 1;
                        end if;

                        button_lock <= 2499999;

                    end if;


                ----------------------------------------------------
                -- SET MODE
                ----------------------------------------------------

                elsif (set_mode = '1') and
                      (main_state = SET_IDLE) and
                      (button_lock = 0) then


                    ----------------------------------------------
                    -- UP -> potvrdi i upisi vrijeme
                    ----------------------------------------------

                    if (btn_up = '1') and
                       (up_old = '0') then

                        button_lock <= 2499999;

                        main_state <=
                            WRITE_HOURS_START;


                    ----------------------------------------------
                    -- RIGHT -> sljedece polje
                    ----------------------------------------------

                    elsif (btn_right = '1') and
                          (right_old = '0') then

                        if set_field = 2 then
                            set_field <= 0;
                        else
                            set_field <=
                                set_field + 1;
                        end if;

                        button_lock <= 2499999;


                    ----------------------------------------------
                    -- LEFT -> prethodno polje
                    ----------------------------------------------

                    elsif (btn_left = '1') and
                          (left_old = '0') then

                        if set_field = 0 then
                            set_field <= 2;
                        else
                            set_field <=
                                set_field - 1;
                        end if;

                        button_lock <= 2499999;


                    ----------------------------------------------
                    -- F1 -> +1
                    ----------------------------------------------

                    elsif (btn_f1 = '1') and
                          (f1_old = '0') then

                        case set_field is


                            -- sekunde
                            when 0 =>

                                if set_seconds = 59 then
                                    set_seconds <= 0;
                                else
                                    set_seconds <=
                                        set_seconds + 1;
                                end if;


                            -- minute
                            when 1 =>

                                if set_minutes = 59 then
                                    set_minutes <= 0;
                                else
                                    set_minutes <=
                                        set_minutes + 1;
                                end if;


                            -- sati
                            when 2 =>

                                if set_hours = 23 then
                                    set_hours <= 0;
                                else
                                    set_hours <=
                                        set_hours + 1;
                                end if;


                            when others =>
                                null;

                        end case;

                        button_lock <= 2499999;


                    ----------------------------------------------
                    -- F2 -> -1
                    ----------------------------------------------

                    elsif (btn_f2 = '1') and
                          (f2_old = '0') then

                        case set_field is


                            -- sekunde
                            when 0 =>

                                if set_seconds = 0 then
                                    set_seconds <= 59;
                                else
                                    set_seconds <=
                                        set_seconds - 1;
                                end if;


                            -- minute
                            when 1 =>

                                if set_minutes = 0 then
                                    set_minutes <= 59;
                                else
                                    set_minutes <=
                                        set_minutes - 1;
                                end if;


                            -- sati
                            when 2 =>

                                if set_hours = 0 then
                                    set_hours <= 23;
                                else
                                    set_hours <=
                                        set_hours - 1;
                                end if;


                            when others =>
                                null;

                        end case;

                        button_lock <= 2499999;

                    end if;

                end if;


                ----------------------------------------------------
                -- GLAVNI FSM
                ----------------------------------------------------

                case main_state is


                    ------------------------------------------------
                    -- Startup
                    ------------------------------------------------

                    when WAIT_STARTUP =>

                        if startup_counter = 2499999 then

                            startup_counter <= 0;

                            main_state <=
                                CHECK_ST_START;

                        else

                            startup_counter <=
                                startup_counter + 1;

                        end if;


                    ------------------------------------------------
                    -- Procitaj registar sekundi i ST bit
                    ------------------------------------------------

                    when CHECK_ST_START =>

                        if master_busy = '0' then

                            master_reg_addr <= x"00";
                            master_read_op <= '1';

                            master_start <= '1';

                            main_state <=
                                CHECK_ST_WAIT;

                        end if;


                    when CHECK_ST_WAIT =>

                        if master_done = '1' then

                            if master_error = '1' then

                                error_latched <= '1';

                                second_counter <=
                                    24999999;

                                main_state <=
                                    WAIT_ONE_SECOND;

                            else

                                error_latched <= '0';

                                rtc_seconds <=
                                    master_read_data;


                                if master_read_data(7) = '0' then

                                    master_reg_addr <= x"00";

                                    master_write_data <=
                                        '1' &
                                        master_read_data(
                                            6 downto 0
                                        );

                                    master_read_op <= '0';

                                    main_state <=
                                        START_RTC_START;

                                else

                                    second_counter <=
                                        24999999;

                                    main_state <=
                                        WAIT_ONE_SECOND;

                                end if;

                            end if;

                        end if;


                    ------------------------------------------------
                    -- Start RTC
                    ------------------------------------------------

                    when START_RTC_START =>

                        if master_busy = '0' then

                            master_start <= '1';

                            main_state <=
                                START_RTC_WAIT;

                        end if;


                    when START_RTC_WAIT =>

                        if master_done = '1' then

                            if master_error = '1' then
                                error_latched <= '1';
                            else
                                error_latched <= '0';
                            end if;

                            second_counter <=
                                24999999;

                            main_state <=
                                WAIT_ONE_SECOND;

                        end if;


                    ------------------------------------------------
                    -- Normalno cekanje
                    ------------------------------------------------

                    when WAIT_ONE_SECOND =>


                        --------------------------------------------
                        -- Ulazak u SET mode
                        --------------------------------------------

                        if set_request = '1' then

                            set_request <= '0';

                            set_mode <= '1';

                            -- pocinjemo od sati
                            set_field <= 2;


                            -- trenutni sati
                            set_hours <=
                                bcd_to_int(
                                    "00" &
                                    rtc_hours(5 downto 0)
                                );


                            -- trenutne minute
                            set_minutes <=
                                bcd_to_int(
                                    '0' &
                                    rtc_minutes(6 downto 0)
                                );


                            -- trenutne sekunde
                            set_seconds <=
                                bcd_to_int(
                                    '0' &
                                    rtc_seconds(6 downto 0)
                                );


                            main_state <= SET_IDLE;


                        elsif second_counter = 24999999 then

                            second_counter <= 0;

                            main_state <=
                                READ_HOURS_START;

                        else

                            second_counter <=
                                second_counter + 1;

                        end if;


                    ------------------------------------------------
                    -- SATI READ
                    ------------------------------------------------

                    when READ_HOURS_START =>

                        if master_busy = '0' then

                            master_reg_addr <= x"02";
                            master_read_op <= '1';

                            master_start <= '1';

                            main_state <=
                                READ_HOURS_WAIT;

                        end if;


                    when READ_HOURS_WAIT =>

                        if master_done = '1' then

                            if master_error = '1' then

                                error_latched <= '1';

                            else

                                rtc_hours <=
                                    master_read_data;

                            end if;

                            main_state <=
                                READ_MINUTES_START;

                        end if;


                    ------------------------------------------------
                    -- MINUTE READ
                    ------------------------------------------------

                    when READ_MINUTES_START =>

                        if master_busy = '0' then

                            master_reg_addr <= x"01";
                            master_read_op <= '1';

                            master_start <= '1';

                            main_state <=
                                READ_MINUTES_WAIT;

                        end if;


                    when READ_MINUTES_WAIT =>

                        if master_done = '1' then

                            if master_error = '1' then

                                error_latched <= '1';

                            else

                                rtc_minutes <=
                                    master_read_data;

                            end if;

                            main_state <=
                                READ_SECONDS_START;

                        end if;


                    ------------------------------------------------
                    -- SEKUNDE READ
                    ------------------------------------------------

                    when READ_SECONDS_START =>

                        if master_busy = '0' then

                            master_reg_addr <= x"00";
                            master_read_op <= '1';

                            master_start <= '1';

                            main_state <=
                                READ_SECONDS_WAIT;

                        end if;


                    when READ_SECONDS_WAIT =>

                        if master_done = '1' then

                            if master_error = '1' then

                                error_latched <= '1';

                            else

                                rtc_seconds <=
                                    master_read_data;

                                error_latched <= '0';

                            end if;

                            main_state <=
                                UART_MESSAGE_START;

                        end if;


                    ------------------------------------------------
                    -- UART
                    ------------------------------------------------

                    when UART_MESSAGE_START =>

                        message_index <= 0;

                        main_state <=
                            UART_SEND_BYTE;


                    when UART_SEND_BYTE =>

                        if uart_busy = '0' then

                            uart_start <= '1';

                            main_state <=
                                UART_WAIT_BYTE;

                        end if;


                    when UART_WAIT_BYTE =>

                        if uart_done = '1' then

                            if message_index = 15 then

                                second_counter <= 0;

                                main_state <=
                                    WAIT_ONE_SECOND;

                            else

                                message_index <=
                                    message_index + 1;

                                main_state <=
                                    UART_SEND_BYTE;

                            end if;

                        end if;


                    ------------------------------------------------
                    -- SET mode
                    ------------------------------------------------

                    when SET_IDLE =>

                        null;


                    ------------------------------------------------
                    -- WRITE SATI
                    ------------------------------------------------

                    when WRITE_HOURS_START =>

                        if master_busy = '0' then

                            master_reg_addr <= x"02";

                            master_write_data <=
                                set_hours_bcd;

                            master_read_op <= '0';

                            master_start <= '1';

                            main_state <=
                                WRITE_HOURS_WAIT;

                        end if;


                    when WRITE_HOURS_WAIT =>

                        if master_done = '1' then

                            if master_error = '1' then

                                error_latched <= '1';

                            end if;

                            main_state <=
                                WRITE_MINUTES_START;

                        end if;


                    ------------------------------------------------
                    -- WRITE MINUTE
                    ------------------------------------------------

                    when WRITE_MINUTES_START =>

                        if master_busy = '0' then

                            master_reg_addr <= x"01";

                            master_write_data <=
                                set_minutes_bcd;

                            master_read_op <= '0';

                            master_start <= '1';

                            main_state <=
                                WRITE_MINUTES_WAIT;

                        end if;


                    when WRITE_MINUTES_WAIT =>

                        if master_done = '1' then

                            if master_error = '1' then

                                error_latched <= '1';

                            end if;

                            main_state <=
                                WRITE_SECONDS_START;

                        end if;


                    ------------------------------------------------
                    -- WRITE SEKUNDE
                    ------------------------------------------------

                    when WRITE_SECONDS_START =>

                        if master_busy = '0' then

                            master_reg_addr <= x"00";

                            -- ST = 1
                            master_write_data <=
                                '1' &
                                set_seconds_bcd(
                                    6 downto 0
                                );

                            master_read_op <= '0';

                            master_start <= '1';

                            main_state <=
                                WRITE_SECONDS_WAIT;

                        end if;


                    when WRITE_SECONDS_WAIT =>

                        if master_done = '1' then

                            if master_error = '1' then

                                error_latched <= '1';

                            else

                                error_latched <= '0';

                            end if;


                            ----------------------------------------
                            -- Izlazak iz SET moda
                            ----------------------------------------

                            set_mode <= '0';

                            second_counter <= 0;


                            ----------------------------------------
                            -- Odmah procitaj novo vrijeme
                            ----------------------------------------

                            main_state <=
                                READ_HOURS_START;

                        end if;


                    when others =>

                        main_state <= WAIT_STARTUP;

                end case;

            end if;

        end if;

    end process;


    ----------------------------------------------------------------
    -- LED prikaz
    ----------------------------------------------------------------

    process(
        set_mode,
        set_field,
        izbor,

        set_seconds_bcd,
        set_minutes_bcd,
        set_hours_bcd,

        rtc_seconds,
        rtc_minutes,
        rtc_hours,

        blink_state,
        set_blink_state,

        error_latched
    )
    begin


        if error_latched = '1' then

            led <= "11111111";


        elsif set_mode = '1' then


            --------------------------------------------------------
            -- SET MODE
            --
            -- LED6..0 trepere kako bi bilo jasno
            -- da se vrijednost trenutno podesava.
            --------------------------------------------------------

            if set_blink_state = '0' then

                led(6 downto 0) <=
                    (others => '0');

            else

                case set_field is


                    -- SEKUNDE
                    when 0 =>

                        led(6 downto 0) <=
                            set_seconds_bcd(
                                6 downto 0
                            );


                    -- MINUTE
                    when 1 =>

                        led(6 downto 0) <=
                            set_minutes_bcd(
                                6 downto 0
                            );


                    -- SATI
                    when 2 =>

                        led(6) <= '0';

                        led(5 downto 0) <=
                            set_hours_bcd(
                                5 downto 0
                            );


                    when others =>

                        led(6 downto 0) <=
                            (others => '0');

                end case;

            end if;


            --------------------------------------------------------
            -- LED7 i dalje pokazuje odabrano polje
            --------------------------------------------------------

            case set_field is

                -- sekunde
                when 0 =>
                    led(7) <= '0';

                -- minute
                when 1 =>
                    led(7) <= '1';

                -- sati
                when 2 =>
                    led(7) <= blink_state;

                when others =>
                    led(7) <= '0';

            end case;


        else


            --------------------------------------------------------
            -- NORMALNI REZIM
            --------------------------------------------------------

            case izbor is


                -- SEKUNDE
                when 0 =>

                    led(7) <= '0';

                    led(6 downto 0) <=
                        rtc_seconds(6 downto 0);


                -- MINUTE
                when 1 =>

                    led(7) <= '1';

                    led(6 downto 0) <=
                        rtc_minutes(6 downto 0);


                -- SATI
                when 2 =>

                    led(7) <= blink_state;

                    led(6) <= '0';

                    led(5 downto 0) <=
                        rtc_hours(5 downto 0);


                when others =>

                    led <=
                        (others => '0');

            end case;

        end if;

    end process;


end Behavioral;