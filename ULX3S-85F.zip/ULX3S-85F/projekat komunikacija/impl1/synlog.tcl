run_tcl -fg proj_impl1_synplify.tcl
