library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity uart_echo_top is

    Port (
        clk_25m  : in  STD_LOGIC;
        btn_down : in  STD_LOGIC;

        rs232_rx : in  STD_LOGIC;
        rs232_tx : out STD_LOGIC;

        led      : out STD_LOGIC_VECTOR(7 downto 0)
    );

end uart_echo_top;


architecture Structural of uart_echo_top is

    signal rx_data  :
        STD_LOGIC_VECTOR(7 downto 0);

    signal rx_valid :
        STD_LOGIC;


    signal tx_data  :
        STD_LOGIC_VECTOR(7 downto 0);

    signal tx_start :
        STD_LOGIC := '0';

    signal tx_busy :
        STD_LOGIC;


    signal led_reg :
        STD_LOGIC_VECTOR(7 downto 0)
        := (others => '0');


    -- Jednobajtni privremeni bafer
    signal pending_data :
        STD_LOGIC_VECTOR(7 downto 0)
        := (others => '0');

    signal pending_valid :
        STD_LOGIC := '0';

begin


    --------------------------------------------------
    -- UART RX
    --------------------------------------------------

    RX_MODULE : entity work.uart_rx

        generic map (
            CLK_FREQ  => 25000000,
            BAUD_RATE => 115200
        )

        port map (
            clk        => clk_25m,
            reset      => btn_down,
            rx         => rs232_rx,
            data_out   => rx_data,
            data_valid => rx_valid
        );


    --------------------------------------------------
    -- UART TX
    --------------------------------------------------

    TX_MODULE : entity work.uart_tx

        generic map (
            CLK_FREQ  => 25000000,
            BAUD_RATE => 115200
        )

        port map (
            clk      => clk_25m,
            reset    => btn_down,
            data_in  => tx_data,
            tx_start => tx_start,
            tx       => rs232_tx,
            tx_busy  => tx_busy
        );


    --------------------------------------------------
    -- ECHO LOGIKA
    --------------------------------------------------

    process(clk_25m)
    begin

        if rising_edge(clk_25m) then

            if btn_down = '1' then

                led_reg       <= (others => '0');
                tx_data       <= (others => '0');
                tx_start      <= '0';

                pending_data  <= (others => '0');
                pending_valid <= '0';

            else

                -- podrazumijevano nema nove TX komande
                tx_start <= '0';


                --------------------------------------
                -- Novi primljeni podatak
                --------------------------------------

                if rx_valid = '1' then

                    -- prikazi bajt na LED-icama
                    led_reg <= rx_data;

                end if;


                --------------------------------------
                -- TX je slobodan
                --------------------------------------

                if tx_busy = '0' then


                    -- Ako vec postoji podatak u baferu
                    if pending_valid = '1' then

                        tx_data  <= pending_data;
                        tx_start <= '1';


                        -- Ako je istovremeno stigao novi bajt,
                        -- sacuvaj novi u baferu
                        if rx_valid = '1' then

                            pending_data  <= rx_data;
                            pending_valid <= '1';

                        else

                            pending_valid <= '0';

                        end if;


                    -- Nema podatka u baferu,
                    -- ali je upravo stigao novi bajt
                    elsif rx_valid = '1' then

                        tx_data  <= rx_data;
                        tx_start <= '1';

                    end if;


                --------------------------------------
                -- TX je zauzet
                --------------------------------------

                elsif rx_valid = '1' then

                    pending_data  <= rx_data;
                    pending_valid <= '1';

                end if;

            end if;

        end if;

    end process;


    led <= led_reg;


end Structural;