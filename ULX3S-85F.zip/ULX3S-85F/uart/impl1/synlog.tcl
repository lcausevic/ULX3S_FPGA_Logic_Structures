run_tcl -fg uart_impl1_synplify.tcl
