library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity i2c_rtc_master is

    generic (
        -- Jedan I2C bit koristi cetiri faze.
        -- 25 MHz / (4 * 62) ~= 100.8 kHz
        TICK_DIV : positive := 62
    );

    port (
        clk        : in  STD_LOGIC;
        reset      : in  STD_LOGIC;

        start      : in  STD_LOGIC;

        -- '1' = citanje
        -- '0' = pisanje
        read_op    : in  STD_LOGIC;

        reg_addr   : in  STD_LOGIC_VECTOR(7 downto 0);
        write_data : in  STD_LOGIC_VECTOR(7 downto 0);

        read_data  : out STD_LOGIC_VECTOR(7 downto 0);

        busy       : out STD_LOGIC;
        done       : out STD_LOGIC;
        ack_error  : out STD_LOGIC;

        sda        : inout STD_LOGIC;
        scl        : inout STD_LOGIC
    );

end i2c_rtc_master;


architecture Behavioral of i2c_rtc_master is

    ------------------------------------------------------------
    -- MCP7940N
    --
    -- 7-bit I2C adresa = 0x6F = 1101111
    --
    -- WRITE:
    -- 1101111 0 = DE
    --
    -- READ:
    -- 1101111 1 = DF
    ------------------------------------------------------------

    constant RTC_WRITE :
        STD_LOGIC_VECTOR(7 downto 0) := x"DE";

    constant RTC_READ :
        STD_LOGIC_VECTOR(7 downto 0) := x"DF";


   

    type state_type is (

        IDLE,

        START_1,
        START_2,
        START_3,

        SEND_SETUP,
        SEND_HIGH,
        SEND_HOLD,
        SEND_LOW,

        ACK_SETUP,
        ACK_HIGH,
        ACK_SAMPLE,
        ACK_LOW,

        REP_START_1,
        REP_START_2,
        REP_START_3,
        REP_START_4,

        READ_SETUP,
        READ_HIGH,
        READ_SAMPLE,
        READ_LOW,

        NACK_SETUP,
        NACK_HIGH,
        NACK_HOLD,
        NACK_LOW,

        STOP_1,
        STOP_2,
        STOP_3,
        STOP_4
    );

    signal state : state_type := IDLE;


    ------------------------------------------------------------
    -- Dijelitelj takta
    ------------------------------------------------------------

    signal tick_counter :
        integer range 0 to TICK_DIV - 1 := 0;


    ------------------------------------------------------------
    -- Open-drain upravljanje
    ------------------------------------------------------------

    signal sda_low : STD_LOGIC := '0';
    signal scl_low : STD_LOGIC := '0';


    ------------------------------------------------------------
    -- Parametri trenutne transakcije
    ------------------------------------------------------------

    signal op_read_latched :
        STD_LOGIC := '1';

    signal reg_latched :
        STD_LOGIC_VECTOR(7 downto 0)
        := (others => '0');

    signal write_latched :
        STD_LOGIC_VECTOR(7 downto 0)
        := (others => '0');


    ------------------------------------------------------------
    -- Podatkovni registri
    ------------------------------------------------------------

    signal tx_byte :
        STD_LOGIC_VECTOR(7 downto 0)
        := (others => '0');

    signal rx_byte :
        STD_LOGIC_VECTOR(7 downto 0)
        := (others => '0');

    signal data_reg :
        STD_LOGIC_VECTOR(7 downto 0)
        := (others => '0');

    signal bit_index :
        integer range 0 to 7 := 7;


    ------------------------------------------------------------
    -- 0 = RTC_WRITE
    -- 1 = adresa RTC registra
    -- 2 = RTC_READ
    -- 3 = podatak kod WRITE operacije
    ------------------------------------------------------------

    signal send_stage :
        integer range 0 to 3 := 0;


    ------------------------------------------------------------
    -- Statusni signali
    ------------------------------------------------------------

    signal busy_reg :
        STD_LOGIC := '0';

    signal done_reg :
        STD_LOGIC := '0';

    signal error_reg :
        STD_LOGIC := '0';

    signal nack_seen :
        STD_LOGIC := '0';


begin


    ------------------------------------------------------------
    -- I2C je open-drain.
    --
    -- '0' = FPGA aktivno vuce liniju na nulu
    -- 'Z' = FPGA otpusta liniju; pull-up je podize na '1'
    ------------------------------------------------------------

    sda <= '0' when sda_low = '1' else 'Z';
    scl <= '0' when scl_low = '1' else 'Z';

    read_data <= data_reg;

    busy      <= busy_reg;
    done      <= done_reg;
    ack_error <= error_reg;


    ------------------------------------------------------------
    -- Glavni I2C proces
    ------------------------------------------------------------

    process(clk)
    begin

        if rising_edge(clk) then

            done_reg <= '0';


            ----------------------------------------------------
            -- RESET
            ----------------------------------------------------

            if reset = '1' then

                state <= IDLE;

                tick_counter <= 0;

                sda_low <= '0';
                scl_low <= '0';

                busy_reg <= '0';
                done_reg <= '0';
                error_reg <= '0';
                nack_seen <= '0';

                op_read_latched <= '1';

                reg_latched <= (others => '0');
                write_latched <= (others => '0');

                tx_byte <= (others => '0');
                rx_byte <= (others => '0');
                data_reg <= (others => '0');

                bit_index <= 7;
                send_stage <= 0;


            ----------------------------------------------------
            -- NOVA TRANSAKCIJA
            ----------------------------------------------------

            elsif (state = IDLE) and (start = '1') then

                op_read_latched <= read_op;
                reg_latched <= reg_addr;
                write_latched <= write_data;

                busy_reg <= '1';
                error_reg <= '0';
                nack_seen <= '0';

                tick_counter <= 0;

                state <= START_1;


            ----------------------------------------------------
            -- I2C vremenska baza
            ----------------------------------------------------

            elsif state /= IDLE then

                if tick_counter = TICK_DIV - 1 then

                    tick_counter <= 0;


                    case state is


                        ------------------------------------------------
                        -- START
                        ------------------------------------------------

                        when START_1 =>

                            sda_low <= '0';
                            scl_low <= '0';

                            state <= START_2;


                        when START_2 =>

                            -- SDA: 1 -> 0 dok je SCL = 1

                            sda_low <= '1';
                            scl_low <= '0';

                            state <= START_3;


                        when START_3 =>

                            scl_low <= '1';

                            tx_byte <= RTC_WRITE;
                            bit_index <= 7;
                            send_stage <= 0;

                            state <= SEND_SETUP;



                        ------------------------------------------------
                        -- SLANJE JEDNOG BAJTA
                        ------------------------------------------------

                        when SEND_SETUP =>

                            scl_low <= '1';

                            if tx_byte(bit_index) = '0' then
                                sda_low <= '1';
                            else
                                sda_low <= '0';
                            end if;

                            state <= SEND_HIGH;


                        when SEND_HIGH =>

                            scl_low <= '0';

                            state <= SEND_HOLD;


                        when SEND_HOLD =>

                            state <= SEND_LOW;


                        when SEND_LOW =>

                            scl_low <= '1';

                            if bit_index = 0 then

                                state <= ACK_SETUP;

                            else

                                bit_index <= bit_index - 1;

                                state <= SEND_SETUP;

                            end if;



                        ------------------------------------------------
                        -- ACK
                        ------------------------------------------------

                        when ACK_SETUP =>

                            scl_low <= '1';

                            -- Master otpusta SDA

                            sda_low <= '0';

                            nack_seen <= '0';

                            state <= ACK_HIGH;


                        when ACK_HIGH =>

                            scl_low <= '0';

                            state <= ACK_SAMPLE;


                        when ACK_SAMPLE =>

                            if sda /= '0' then

                                nack_seen <= '1';
                                error_reg <= '1';

                            end if;

                            state <= ACK_LOW;


                        when ACK_LOW =>

                            scl_low <= '1';


                            if nack_seen = '1' then

                                state <= STOP_1;


                            elsif send_stage = 0 then

                                ------------------------------------------------
                                -- RTC adresa je prihvacena.
                                -- Saljemo adresu registra.
                                ------------------------------------------------

                                tx_byte <= reg_latched;
                                bit_index <= 7;
                                send_stage <= 1;

                                state <= SEND_SETUP;


                            elsif send_stage = 1 then

                                ------------------------------------------------
                                -- Adresa registra je postavljena.
                                ------------------------------------------------

                                if op_read_latched = '1' then

                                    state <= REP_START_1;

                                else

                                    tx_byte <= write_latched;
                                    bit_index <= 7;
                                    send_stage <= 3;

                                    state <= SEND_SETUP;

                                end if;


                            elsif send_stage = 2 then

                                ------------------------------------------------
                                -- RTC_READ je prihvacen.
                                -- Pocinjemo citanje.
                                ------------------------------------------------

                                bit_index <= 7;

                                rx_byte <=
                                    (others => '0');

                                state <= READ_SETUP;


                            else

                                ------------------------------------------------
                                -- WRITE podatak je prihvacen.
                                ------------------------------------------------

                                state <= STOP_1;

                            end if;



                        ------------------------------------------------
                        -- REPEATED START
                        ------------------------------------------------

                        when REP_START_1 =>

                            scl_low <= '1';
                            sda_low <= '0';

                            state <= REP_START_2;


                        when REP_START_2 =>

                            scl_low <= '0';
                            sda_low <= '0';

                            state <= REP_START_3;


                        when REP_START_3 =>

                            -- SDA: 1 -> 0 dok je SCL = 1

                            sda_low <= '1';

                            state <= REP_START_4;


                        when REP_START_4 =>

                            scl_low <= '1';

                            tx_byte <= RTC_READ;
                            bit_index <= 7;
                            send_stage <= 2;

                            state <= SEND_SETUP;



                        ------------------------------------------------
                        -- CITANJE JEDNOG BAJTA
                        ------------------------------------------------

                        when READ_SETUP =>

                            scl_low <= '1';

                            -- Master otpusta SDA

                            sda_low <= '0';

                            state <= READ_HIGH;


                        when READ_HIGH =>

                            scl_low <= '0';

                            state <= READ_SAMPLE;


                        when READ_SAMPLE =>

                            if sda = '0' then

                                rx_byte(bit_index) <= '0';

                            else

                                rx_byte(bit_index) <= '1';

                            end if;

                            state <= READ_LOW;


                        when READ_LOW =>

                            scl_low <= '1';

                            if bit_index = 0 then

                                state <= NACK_SETUP;

                            else

                                bit_index <= bit_index - 1;

                                state <= READ_SETUP;

                            end if;



                        ------------------------------------------------
                        -- MASTER NACK
                        --
                        -- Citamo samo jedan bajt.
                        ------------------------------------------------

                        when NACK_SETUP =>

                            scl_low <= '1';

                            -- SDA otpustena = logicka jedinica

                            sda_low <= '0';

                            state <= NACK_HIGH;


                        when NACK_HIGH =>

                            scl_low <= '0';

                            state <= NACK_HOLD;


                        when NACK_HOLD =>

                            state <= NACK_LOW;


                        when NACK_LOW =>

                            scl_low <= '1';

                            state <= STOP_1;



                        ------------------------------------------------
                        -- STOP
                        ------------------------------------------------

                        when STOP_1 =>

                            scl_low <= '1';
                            sda_low <= '1';

                            state <= STOP_2;


                        when STOP_2 =>

                            -- SCL ide na 1 dok je SDA jos 0

                            scl_low <= '0';
                            sda_low <= '1';

                            state <= STOP_3;


                        when STOP_3 =>

                            state <= STOP_4;


                        when STOP_4 =>

                            -- SDA: 0 -> 1 dok je SCL = 1

                            sda_low <= '0';

                            if op_read_latched = '1' then

                                data_reg <= rx_byte;

                            end if;

                            busy_reg <= '0';
                            done_reg <= '1';

                            state <= IDLE;


                        when others =>

                            state <= IDLE;

                    end case;


                else

                    tick_counter <=
                        tick_counter + 1;

                end if;

            end if;

        end if;

    end process;

end Behavioral;