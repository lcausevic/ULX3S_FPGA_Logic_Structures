run_tcl -fg i2c_impl1_synplify.tcl
