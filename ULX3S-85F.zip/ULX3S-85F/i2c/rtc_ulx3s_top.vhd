library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity rtc_ulx3s_top is

    port (
        clk_25m   : in  STD_LOGIC;

        btn_left  : in  STD_LOGIC;
        btn_right : in  STD_LOGIC;
        btn_down  : in  STD_LOGIC;

        gpdi_sda  : inout STD_LOGIC;
        gpdi_scl  : inout STD_LOGIC;

        led       : out STD_LOGIC_VECTOR(7 downto 0)
    );

end rtc_ulx3s_top;


architecture Behavioral of rtc_ulx3s_top is


    ------------------------------------------------------------
    -- 0 = SEKUNDE
    -- 1 = MINUTE
    -- 2 = SATI
    ------------------------------------------------------------

    signal izbor :
        integer range 0 to 2 := 0;


    ------------------------------------------------------------
    -- Odabrani RTC registar
    ------------------------------------------------------------

    signal selected_reg :
        STD_LOGIC_VECTOR(7 downto 0)
        := x"00";


    ------------------------------------------------------------
    -- I2C komanda
    ------------------------------------------------------------

    signal master_start :
        STD_LOGIC := '0';

    signal master_read_op :
        STD_LOGIC := '1';

    signal master_reg_addr :
        STD_LOGIC_VECTOR(7 downto 0)
        := x"00";

    signal master_write_data :
        STD_LOGIC_VECTOR(7 downto 0)
        := (others => '0');


    ------------------------------------------------------------
    -- I2C rezultat
    ------------------------------------------------------------

    signal master_read_data :
        STD_LOGIC_VECTOR(7 downto 0)
        := (others => '0');

    signal master_busy :
        STD_LOGIC;

    signal master_done :
        STD_LOGIC;

    signal master_error :
        STD_LOGIC;


    ------------------------------------------------------------
    -- Vrijednost koja se prikazuje
    ------------------------------------------------------------

    signal display_data :
        STD_LOGIC_VECTOR(7 downto 0)
        := (others => '0');


    signal error_latched :
        STD_LOGIC := '0';


    ------------------------------------------------------------
    -- Automatsko osvjezavanje:
    -- 25 MHz * 0.2 s = 5 000 000
    ------------------------------------------------------------

    signal refresh_counter :
        integer range 0 to 4999999 := 0;


    ------------------------------------------------------------
    -- Pocetno cekanje:
    -- oko 100 ms
    ------------------------------------------------------------

    signal startup_counter :
        integer range 0 to 2499999 := 0;


    ------------------------------------------------------------
    -- Debounce tipki:
    -- oko 100 ms
    ------------------------------------------------------------

    signal button_lock :
        integer range 0 to 2499999 := 0;

    signal left_old :
        STD_LOGIC := '0';

    signal right_old :
        STD_LOGIC := '0';


    ------------------------------------------------------------
    -- Blink za prikaz SATI
    --
    -- Promjena svakih 0.5 s
    -- puni period = 1 s
    ------------------------------------------------------------

    signal blink_counter :
        integer range 0 to 12499999 := 0;

    signal blink_state :
        STD_LOGIC := '0';


    ------------------------------------------------------------
    -- Upravljacki automat
    ------------------------------------------------------------

    type top_state_type is (

        WAIT_STARTUP,

        CHECK_ST_START,
        CHECK_ST_WAIT,

        START_RTC_START,
        START_RTC_WAIT,

        NORMAL_IDLE,
        NORMAL_WAIT

    );

    signal top_state :
        top_state_type := WAIT_STARTUP;


begin


    ------------------------------------------------------------
    -- Odabir RTC registra
    ------------------------------------------------------------

    process(izbor)
    begin

        case izbor is

            when 0 =>
                selected_reg <= x"00";
                -- sekunde

            when 1 =>
                selected_reg <= x"01";
                -- minute

            when 2 =>
                selected_reg <= x"02";
                -- sati

            when others =>
                selected_reg <= x"00";

        end case;

    end process;


    ------------------------------------------------------------
    -- I2C MASTER
    ------------------------------------------------------------

    RTC_I2C_MASTER :
        entity work.i2c_rtc_master

        generic map (
            TICK_DIV => 62
        )

        port map (

            clk        => clk_25m,
            reset      => btn_down,

            start      => master_start,
            read_op    => master_read_op,

            reg_addr   => master_reg_addr,
            write_data => master_write_data,

            read_data  => master_read_data,

            busy       => master_busy,
            done       => master_done,
            ack_error  => master_error,

            sda        => gpdi_sda,
            scl        => gpdi_scl
        );


    ------------------------------------------------------------
    -- Blink generator
    ------------------------------------------------------------

    process(clk_25m)
    begin

        if rising_edge(clk_25m) then

            if btn_down = '1' then

                blink_counter <= 0;
                blink_state <= '0';

            else

                if blink_counter = 12499999 then

                    blink_counter <= 0;

                    blink_state <=
                        NOT blink_state;

                else

                    blink_counter <=
                        blink_counter + 1;

                end if;

            end if;

        end if;

    end process;


    ------------------------------------------------------------

    ------------------------------------------------------------

    process(clk_25m)
    begin

        if rising_edge(clk_25m) then


            ----------------------------------------------------
            -- master_start je impuls od jednog clk perioda
            ----------------------------------------------------

            master_start <= '0';


            ----------------------------------------------------
            -- Pamcenje prethodnog stanja tipki
            ----------------------------------------------------

            left_old <= btn_left;
            right_old <= btn_right;


            ----------------------------------------------------
            -- RESET
            ----------------------------------------------------

            if btn_down = '1' then

                izbor <= 0;

                master_start <= '0';
                master_read_op <= '1';

                master_reg_addr <= x"00";
                master_write_data <= x"00";

                display_data <=
                    (others => '0');

                error_latched <= '0';

                refresh_counter <= 0;
                startup_counter <= 0;

                button_lock <= 0;

                top_state <= WAIT_STARTUP;


            else


                ------------------------------------------------
                -- Debounce
                ------------------------------------------------

                if button_lock > 0 then

                    button_lock <=
                        button_lock - 1;

                end if;


                ------------------------------------------------
                -- RIGHT / LEFT
                ------------------------------------------------

                if button_lock = 0 then


                    if (btn_right = '1') and
                       (right_old = '0') then

                        ------------------------------------------------
                        -- SEKUNDE -> MINUTE -> SATI -> SEKUNDE
                        ------------------------------------------------

                        if izbor = 2 then
                            izbor <= 0;
                        else
                            izbor <= izbor + 1;
                        end if;

                        button_lock <= 2499999;

                     
                        refresh_counter <= 4999999;


                    elsif (btn_left = '1') and
                          (left_old = '0') then

                        ------------------------------------------------
                        -- SEKUNDE <- MINUTE <- SATI <- SEKUNDE
                        ------------------------------------------------

                        if izbor = 0 then
                            izbor <= 2;
                        else
                            izbor <= izbor - 1;
                        end if;

                        button_lock <= 2499999;

                        refresh_counter <= 4999999;

                    end if;

                end if;


                ------------------------------------------------
                -- TOP-LEVEL FSM
                ------------------------------------------------

                case top_state is


                    ------------------------------------------------
                    -- Pocetno cekanje
                    ------------------------------------------------

                    when WAIT_STARTUP =>

                        if startup_counter = 2499999 then

                            startup_counter <= 0;

                            top_state <=
                                CHECK_ST_START;

                        else

                            startup_counter <=
                                startup_counter + 1;

                        end if;



                    ------------------------------------------------
                    -- Procitaj registar sekundi
                    ------------------------------------------------

                    when CHECK_ST_START =>

                        if master_busy = '0' then

                            master_reg_addr <= x"00";

                            master_read_op <= '1';

                            master_start <= '1';

                            top_state <=
                                CHECK_ST_WAIT;

                        end if;



                    when CHECK_ST_WAIT =>

                        if master_done = '1' then

                            if master_error = '1' then

                                error_latched <= '1';

                                top_state <=
                                    NORMAL_IDLE;


                            else

                                error_latched <= '0';


                                ------------------------------------------------
                                -- RTCSEC bit 7 = ST
                                --
                                -- ST = 0 -> oscilator zaustavljen
                                -- ST = 1 -> oscilator radi
                                ------------------------------------------------

                                if master_read_data(7) = '0' then

                                    master_reg_addr <= x"00";

                                    ------------------------------------------------
                                    -- Sacuvaj trenutne sekunde,
                                    -- samo postavi ST = 1
                                    ------------------------------------------------

                                    master_write_data <=
                                        '1' &
                                        master_read_data(6 downto 0);

                                    master_read_op <= '0';

                                    top_state <=
                                        START_RTC_START;


                                else

                                    top_state <=
                                        NORMAL_IDLE;

                                end if;

                            end if;

                        end if;



                    ------------------------------------------------
                    -- Pokretanje RTC-a
                    ------------------------------------------------

                    when START_RTC_START =>

                        if master_busy = '0' then

                            master_start <= '1';

                            top_state <=
                                START_RTC_WAIT;

                        end if;



                    when START_RTC_WAIT =>

                        if master_done = '1' then

                            if master_error = '1' then
                                error_latched <= '1';
                            else
                                error_latched <= '0';
                            end if;

                            refresh_counter <=
                                4999999;

                            top_state <=
                                NORMAL_IDLE;

                        end if;



                    ------------------------------------------------
                    -- Normalno periodicno citanje
                    ------------------------------------------------

                    when NORMAL_IDLE =>

                        if refresh_counter = 4999999 then

                            refresh_counter <= 0;

                            if master_busy = '0' then

                                master_reg_addr <=
                                    selected_reg;

                                master_read_op <= '1';

                                master_start <= '1';

                                top_state <=
                                    NORMAL_WAIT;

                            end if;


                        else

                            refresh_counter <=
                                refresh_counter + 1;

                        end if;



                    ------------------------------------------------
                    -- Cekanje zavrsetka citanja
                    ------------------------------------------------

                    when NORMAL_WAIT =>

                        if master_done = '1' then

                            if master_error = '1' then

                                error_latched <= '1';

                            else

                                error_latched <= '0';

                                display_data <=
                                    master_read_data;

                            end if;

                            top_state <=
                                NORMAL_IDLE;

                        end if;


                    when others =>

                        top_state <=
                            WAIT_STARTUP;

                end case;

            end if;

        end if;

    end process;


    ------------------------------------------------------------
    -- LED PRIKAZ
    --
    -- LED7 = MODE
    --
    -- SEKUNDE -> LED7 OFF
    -- MINUTE  -> LED7 ON
    -- SATI    -> LED7 BLINK
    --
    -- LED6..0 = BCD podatak iz RTC-a
    ------------------------------------------------------------

    process(
        izbor,
        display_data,
        error_latched,
        blink_state
    )
    begin

        if error_latched = '1' then

            ----------------------------------------------------
            -- Dijagnostika I2C greske
            ----------------------------------------------------

            led <= "11111111";


        else

            ----------------------------------------------------
            -- BCD vrijednost
            ----------------------------------------------------

            led(6 downto 0) <=
                display_data(6 downto 0);


            ----------------------------------------------------
            -- MODE indikator
            ----------------------------------------------------

            case izbor is

                when 0 =>

                    -- SEKUNDE

                    led(7) <= '0';


                when 1 =>

                    -- MINUTE

                    led(7) <= '1';


                when 2 =>

                    -- SATI

                    led(7) <= blink_state;


                when others =>

                    led(7) <= '0';

            end case;

        end if;

    end process;


end Behavioral;