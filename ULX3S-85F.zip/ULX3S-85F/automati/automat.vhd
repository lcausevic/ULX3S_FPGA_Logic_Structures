library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity automat is

    generic (
        CLK_DIV : positive := 25000000
    );

    Port (
        clk_25m  : in  STD_LOGIC;
        btn_down : in  STD_LOGIC;
        sw       : in  STD_LOGIC_VECTOR(3 downto 0);
        led      : out STD_LOGIC_VECTOR(7 downto 0)
    );

end automat;


architecture Behavioral of automat is

    -- stanje = 0 -> stanje a
    -- stanje = 1 -> stanje b

    signal stanje         : STD_LOGIC := '0';
    signal sljedece_stanje : STD_LOGIC := '0';

    -- Kodirani izlaz:
    -- "01" = y1
    -- "10" = y2
    -- "11" = y3

    signal z : STD_LOGIC_VECTOR(1 downto 0) := "00";

    -- Prescaler za promjenu stanja jednom u sekundi
    signal prescaler : INTEGER range 0 to CLK_DIV-1 := 0;

begin


    --------------------------------------------------
    -- SEKVENCIJALNI DIO
    -- Registar trenutnog stanja
    --------------------------------------------------

    process(clk_25m, btn_down)
    begin

        if btn_down = '1' then

            stanje    <= '0';
            prescaler <= 0;

        elsif rising_edge(clk_25m) then

            if prescaler = CLK_DIV-1 then

                prescaler <= 0;
                stanje <= sljedece_stanje;

            else

                prescaler <= prescaler + 1;

            end if;

        end if;

    end process;


    --------------------------------------------------
    -- KOMBINACIONI DIO
    -- Odredjivanje izlaza i sljedeceg stanja
    --------------------------------------------------

    process(stanje, sw)
    begin

        -- podrazumijevane vrijednosti
        sljedece_stanje <= stanje;
        z <= "00";


        case stanje is

            --------------------------------------------------
            -- STANJE a
            --------------------------------------------------

            when '0' =>

                case sw(1 downto 0) is

                    -- x1
                    -- a -> a / y1
                    when "01" =>
                        sljedece_stanje <= '0';
                        z <= "01";

                    -- x2
                    -- a -> b / y2
                    when "10" =>
                        sljedece_stanje <= '1';
                        z <= "10";

                    -- x3
                    -- a -> b / y3
                    when "11" =>
                        sljedece_stanje <= '1';
                        z <= "11";

                    -- ulaz 00 nije definisan kao x1,x2,x3
                    when others =>
                        sljedece_stanje <= stanje;
                        z <= "00";

                end case;


            --------------------------------------------------
            -- STANJE b
            --------------------------------------------------

            when '1' =>

                case sw(1 downto 0) is

                    -- x1
                    -- b -> b / y2
                    when "01" =>
                        sljedece_stanje <= '1';
                        z <= "10";

                    -- x2
                    -- b -> a / y2
                    when "10" =>
                        sljedece_stanje <= '0';
                        z <= "10";

                    -- x3
                    -- b -> a / y3
                    when "11" =>
                        sljedece_stanje <= '0';
                        z <= "11";

                    when others =>
                        sljedece_stanje <= stanje;
                        z <= "00";

                end case;


            when others =>

                sljedece_stanje <= '0';
                z <= "00";

        end case;

    end process;


    --------------------------------------------------
    -- IZLAZI
    --------------------------------------------------

    led(1 downto 0) <= z;

    -- indikator trenutnog stanja:
    -- LED2 = 0 -> a
    -- LED2 = 1 -> b
    led(2) <= stanje;

    led(7 downto 3) <= "00000";


end Behavioral;