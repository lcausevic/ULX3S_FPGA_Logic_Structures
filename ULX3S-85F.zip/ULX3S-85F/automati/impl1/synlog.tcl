run_tcl -fg automat_impl1_synplify.tcl
